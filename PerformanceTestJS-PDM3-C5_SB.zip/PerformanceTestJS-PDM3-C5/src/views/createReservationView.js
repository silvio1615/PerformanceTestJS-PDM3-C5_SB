import Sidebar from "@/components/Sidebar.js";
import { getSession } from "@/utils.js";
import { createReservation } from "@/services/reservation.service.js";
import { navigateTo } from "@/router/router.js";

export default function createReservationView() {
  setTimeout(() => {
    document.querySelector("#createForm")?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const user = getSession();
      const form = e.target;

      try {
        await createReservation({
          userId: user.id,
          workspace: form.workspace.value,
          date: form.date.value,
          startHour: form.startHour.value,
          endHour: form.endHour.value,
          reason: form.reason.value,
          status: "pending"
        });
        alert("Reserva creada exitosamente");
        navigateTo("/home");
      } catch (error) {
        alert("Error: " + error.message);
      }
    });
  });

  return `
    <div class="flex">
      ${Sidebar()}
      <main class="flex-1 p-8 bg-slate-100 min-h-screen">
        <div class="max-w-md mx-auto bg-white rounded-lg shadow p-6">
          <h1 class="text-2xl font-bold mb-6">Nueva Reserva</h1>
          <form id="createForm" class="flex flex-col gap-4">
            <input type="text" name="workspace" placeholder="Espacio de trabajo" required class="border p-2 rounded">
            <input type="date" name="date" required class="border p-2 rounded">
            <input type="time" name="startHour" required class="border p-2 rounded">
            <input type="time" name="endHour" required class="border p-2 rounded">
            <textarea name="reason" placeholder="Motivo" required class="border p-2 rounded"></textarea>
            <button type="submit" class="bg-blue-600 text-white py-2 rounded">Crear Reserva</button>
          </form>
        </div>
      </main>
    </div>
  `;
}
