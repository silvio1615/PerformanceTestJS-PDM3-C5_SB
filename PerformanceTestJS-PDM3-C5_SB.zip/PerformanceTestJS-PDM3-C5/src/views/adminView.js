import Sidebar from "@/components/Sidebar.js";
import { getAllReservations } from "@/services/reservation.service.js";
import ReservationCard from "@/components/ReservationCard.js";
import { homeController } from "@/controllers/home.controller.js";

export default function adminView() {
  setTimeout(() => {
    homeController();
  });

  return `
    <div class="flex">
      ${Sidebar()}
      <main class="flex-1 p-8 bg-slate-100 min-h-screen">
        <div class="">
          <h1 class="text-3xl font-bold mb-8">
            Panel de Administración
          </h1>
          <p class="text-gray-600 mb-6">
            Gestión de todas las reservas del sistema
          </p>
          <div id="reservationsContainer" class="grid grid-cols-2 gap-4">
            <!-- Reservations will be loaded here -->
          </div>
        </div>
      </main>
    </div>
  `;
}
