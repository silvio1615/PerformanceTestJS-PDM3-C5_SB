import loginView from "@/views/loginView.js";
import homeView from "@/views/homeView.js";
import createReservationView from "@/views/createReservationView.js";
import adminView from "@/views/adminView.js";
import { isAuthenticated, isAdmin } from "@/utils.js";

const routes = {
  "/": loginView,
  "/home": homeView,
  "/create-reservation": createReservationView,
  "/admin": adminView,
};

export const navigateTo = (path) => {
  history.pushState({}, "", path);
  router();
};

export const router = () => {
  const app = document.querySelector("#app");
  let path = window.location.pathname;

  // Proteger rutas privadas
  if (path !== "/" && !isAuthenticated()) {
    navigateTo("/");
    return;
  }

  // Proteger ruta admin
  if (path === "/admin" && !isAdmin()) {
    alert("No tienes permisos para acceder al panel de administración");
    navigateTo("/home");
    return;
  }

  const view = routes[path] || loginView;

  app.innerHTML = view();
};

window.addEventListener("popstate", router);
