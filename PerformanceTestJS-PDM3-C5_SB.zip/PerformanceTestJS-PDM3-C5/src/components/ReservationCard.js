import { getSession, isAdmin } from "@/utils.js";

export default function ReservationCard(reservation) {
  const { id, userId, workspace, date, startHour, endHour, reason, status } = reservation;
  const user = getSession();
  const isOwner = user.id === userId;
  const adminUser = isAdmin();

  return `
    <article
      data-reservation-id="${id}"
      class="rounded"
    >
      <h3 class="font-bold text-lg">
        ${workspace}
      </h3>

      <div class="text-sm text-gray-600 my-2">
        <p>Fecha: ${date}</p>
        <p>Horario: ${startHour} - ${endHour}</p>
        <p>Motivo: ${reason}</p>
        <p class="mt-2">
          Estado:
          <span class="">
            ${status}
          </span>
        </p>
      </div>

     </div>

<div class="flex gap-2 mt-4 text-xs">
  <!-- Botones para el Creador / Dueño -->
  ${isOwner ? `
    ${status === "pending" ? '<button class="bg-blue-500 text-white px-3 py-1 rounded btn-edit">Editar</button>' : ''}
    ${status === "pending" || status === "approved" ? '<button class="bg-orange-500 text-white px-3 py-1 rounded btn-cancel">Cancelar</button>' : ''}
  ` : ""}

  <!-- Botones para el Administrador -->
  ${adminUser ? `
    ${status === "pending" ? `
      <button class="bg-green-500 text-white px-3 py-1 rounded btn-approve">Aprobar</button>
      <button class="bg-red-500 text-white px-3 py-1 rounded btn-reject">Rechazar</button>
    ` : ""}
    <button class="bg-gray-500 text-white px-3 py-1 rounded btn-delete">Eliminar</button>
  ` : ""}
</div>

    </article>
  `;
}
