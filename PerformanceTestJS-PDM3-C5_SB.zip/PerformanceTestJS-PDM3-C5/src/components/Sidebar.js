import { removeSession, getSession, isAdmin } from "@/utils.js";
import { navigateTo } from "@/router/router.js";

export default function Sidebar() {
  const user = getSession();
  const adminUser = isAdmin();

  setTimeout(() => {
    document
      .querySelector("#logoutBtn")
      ?.addEventListener("click", () => {
        removeSession();
        navigateTo("/");
      });
  });

  return `
    <aside
      class="w-64 bg-slate-900 text-white h-screen p-5"
    >
      <h2 class="text-2xl font-bold mb-8">
        SPA Base
      </h2>

      <nav class="flex flex-col gap-4">

        <a href="/home" class="px-3 py-1 bg-gray-500 rounded-xl hover:bg-gray-600 transition" data-link>
          Home
        </a>

        <a href="/create-reservation" class="px-3 py-1 bg-blue-600 rounded-xl hover:bg-blue-700 transition" data-link>
          + Nueva Reserva
        </a>

        ${adminUser ? `
          <a href="/admin" class="px-3 py-1 bg-red-600 rounded-xl hover:bg-red-700 transition" data-link>
            Gestionar Reservas
          </a>
        ` : ''}

        <button
          id="logoutBtn"
          class="text-left cursor-pointer text-red-400 hover:text-white hover:bg-red-400 px-3 py-1 rounded-xl"
        >
          Cerrar sesión
        </button>

      </nav>

    </aside>
  `;
}