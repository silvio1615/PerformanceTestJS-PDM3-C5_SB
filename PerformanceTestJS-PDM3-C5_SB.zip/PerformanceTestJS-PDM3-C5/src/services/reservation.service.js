import { http } from "@/api/http";

// Obtener todas las reservas (solo para admin)
export const getAllReservations = () =>
  http.get("/reservations");

// Obtener reservas del usuario actual
export const getUserReservations = (userId) =>
  http.get(`/reservations?userId=${userId}`);

// Crear una nueva reserva
export const createReservation = (data) =>
  http.post("/reservations", data);

// Actualizar una reserva
export const updateReservation = (id, data) =>
  http.put(`/reservations/${id}`, data);

// Eliminar una reserva
export const deleteReservation = (id) =>
  http.delete(`/reservations/${id}`);

// Aprobar una reserva (solo para admin)
export const approveReservation = (id) =>
  http.patch(`/reservations/${id}`, {
    status: "approved"
  });

// Rechazar una reserva (solo para admin)
export const rejectReservation = (id, reason = "") =>
  http.patch(`/reservations/${id}`, {
    status: "rejected",
    rejectionReason: reason
  });