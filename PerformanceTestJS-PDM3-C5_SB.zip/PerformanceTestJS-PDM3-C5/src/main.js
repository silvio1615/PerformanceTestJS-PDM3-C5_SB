import "@/style.css";
import { router, navigateTo } from "@/router/router";

document.addEventListener("DOMContentLoaded", () => {
  router();
});

document.addEventListener("click", (e) => {
  const link = e.target.closest("a[data-link]");
  if (link) {
    e.preventDefault();
    navigateTo(link.getAttribute("href"));
  }
});