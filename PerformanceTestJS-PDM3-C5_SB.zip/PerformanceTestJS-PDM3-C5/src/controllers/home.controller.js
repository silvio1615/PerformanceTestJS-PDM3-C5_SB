import ReservationCard from "@/components/ReservationCard.js";
import { getSession } from "@/utils.js";
import { 
  getAllReservations, 
  updateReservation, 
  deleteReservation,
  approveReservation,
  rejectReservation 
} from "@/services/reservation.service.js";

export const homeController = async () => {
  const container = document.querySelector("#reservationsContainer");
  const user = getSession();
  const reservations = await getAllReservations();

  const filteredReservations =
    user.role === "admin"
      ? reservations
      : reservations.filter((reservation) => reservation.userId === user.id);

  container.innerHTML = filteredReservations?.length
    ? filteredReservations
        .map((reservation) => ReservationCard(reservation))
        .join("")
    : `
      <div class="w-full text-center py-8 col-span-2">
        <p class="text-slate-500">
          No hay reservas disponibles
        </p>
      </div>
    `;

  attachReservationListeners();
};

const attachReservationListeners = () => {
  // Cancelar reserva
  document.querySelectorAll(".btn-cancel").forEach(btn => {
    btn.addEventListener("click", async () => {
      const id = btn.closest("article").dataset.reservationId;
      if (confirm("¿Cancelar esta reserva?")) {
        try {
          await updateReservation(id, { status: "cancelled" });
          alert("Reserva cancelada");
          location.reload();
        } catch (error) {
          alert("Error: " + error.message);
        }
      }
    });
  });

  // Aprobar reserva (admin)
  document.querySelectorAll(".btn-approve").forEach(btn => {
    btn.addEventListener("click", async () => {
      const id = btn.closest("article").dataset.reservationId;
      try {
        await approveReservation(id);
        alert("Reserva aprobada");
        location.reload();
      } catch (error) {
        alert("Error: " + error.message);
      }
    });
  });

  // Rechazar reserva (admin)
  document.querySelectorAll(".btn-reject").forEach(btn => {
    btn.addEventListener("click", async () => {
      const id = btn.closest("article").dataset.reservationId;
      const reason = prompt("Motivo del rechazo:");
      if (reason !== null) {
        try {
          await rejectReservation(id, reason);
          alert("Reserva rechazada");
          location.reload();
        } catch (error) {
          alert("Error: " + error.message);
        }
      }
    });
  });

  // Eliminar reserva (admin)
  document.querySelectorAll(".btn-delete").forEach(btn => {
    btn.addEventListener("click", async () => {
      const id = btn.closest("article").dataset.reservationId;
      if (confirm("¿Eliminar esta reserva?")) {
        try {
          await deleteReservation(id);
          alert("Reserva eliminada");
          location.reload();
        } catch (error) {
          alert("Error: " + error.message);
        }
      }
    });
  });

  // Editar reserva (usuario, solo pending)
  document.querySelectorAll(".btn-edit").forEach(btn => {
    btn.addEventListener("click", async () => {
      const id = btn.closest("article").dataset.reservationId;
      const workspace = prompt("Nuevo espacio:");
      if (workspace) {
        try {
          await updateReservation(id, { workspace });
          alert("Reserva actualizada");
          location.reload();
        } catch (error) {
          alert("Error: " + error.message);
        }
      }
    });
  });
};
